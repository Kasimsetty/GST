(function ($, window, document, undefined) {

	/* Graphs Class */
	var Graphs = function( oInit ) {

		/* Create the settings object */
		var oSettings = $.extend( true, {}, oSettings, {
			"apiUrl" : "http://192.168.30.127/GSTReports.API/api/"
			//"apiUrl" : "http://183.82.50.237/GST/api/"
		});

		/* Init */
		_fnWorkSpace();
		
		/* Methods */
		function _fnWorkSpace() {
			$("#circlechart .chartloader").show();
			$("#divisionchart .chartloader").show();
			$("#divisiondatechart .chartloader").show();
			_fnDatePickers();
			_fnChartsData();
		}

		function _fnDatePickers() {
			var _datepkrs = [ 'fdate', 'tdate' ];

			$.each(_datepkrs, function(index, datepkr) {
				$('#' + datepkr).datepicker().on('changeDate', function(ev) {
					$('#' + datepkr).datepicker('hide');

					$("#circlechart .chartloader").show();
					$("#divisionchart .chartloader").show();
					$("#divisiondatechart .chartloader").show();
					setTimeout(function(){ 
						_fnChartsData();
					}, 500);
				});

				$('#' + datepkr).siblings('div.input-group-addon').on('click', function() {
					$('#' + datepkr).datepicker({showEvent: 'none'}).data('datepicker').show();
					$('#' + datepkr).focus();
				}).css("cursor", "pointer");
			});

			var _date  = new Date();
			var _fdate = (_date.getMonth() + 1) + '/' + _date.getDate() + '/' + _date.getFullYear();
			var _tdate = (_date.getMonth() + 2) + '/' + _date.getDate() + '/' + _date.getFullYear();

			$('#fdate').datepicker('setValue', new Date(_fdate)); //set today date by default
			$('#tdate').datepicker('setValue', new Date(_tdate)); //set 1 week ahead from applicationfdate
		}

		function _fnChartsData() {
			var _url 				= oSettings.apiUrl + 'GetReportInfo';
			var circleData 			= [];
			var divisionData 		= [];
			var divisionByDateData 	= [];
			var params 				= {'FromDate': $('#fdate').val(), 'ToDate': $('#tdate').val()};

			$.post(_url, params, function(res) {
				if (res) {
					if (res._objDivInfo != undefined && res._objDivInfo.length > 0) {
						$.each(res._objDivInfo, function(ik, division){
							divisionData.push({
								'x': division.idDivision ,
								'y': division.regCount,
								'label': division.divisionName,
								'highlightEnabled': true
							});
							
							// Load the chart while last row is looping
							if (ik == (res._objDivInfo.length)-1) {
								_fnDivisionChart( divisionData );

								// Load the circles chart with first row
								var circleParams = divisionData[ik];
								_fnCircleChart( circleParams.x, circleParams.label );
							}
						});
					}

					if (res._objDivInfoDate != undefined && res._objDivInfoDate.length > 0) {
						//var divisionDates = [];
						$.each(res._objDivInfoDate, function(ik, division){
							
							if (division.dateFM != undefined && division.dateFM != '') {
								var formattedDate = new Date(division.dateFM);
								var d = formattedDate.getDate();
								var m =  formattedDate.getMonth();
								m += 1;  // JavaScript months are 0-11	
								var y = formattedDate.getFullYear();
								
								var objIndex = null;
								objIndex = divisionByDateData.findIndex((obj => obj.name === division.divisionName));
								
								if (objIndex != null && objIndex != undefined && divisionByDateData[objIndex] != null && divisionByDateData[objIndex] != undefined) {
									divisionByDateData[objIndex].dataPoints.push({
										'x':new Date(y, d,m), 
										'y': division.regCount
									});
								} else {
									divisionByDateData.push({
										'name' 				: division.divisionName,
										'type' 				: 'spline',
										'yValueFormatString': "#0",
										'showInLegend'		: true,
										'markerSize'		: 5,
										'dataPoints'		: new Array({
											'x'	: new Date(y, d,m), 
											'y'	: division.regCount
										})
									});
								}

								//divisionDates.push( new Date(y, d,m) );
							}

							// Load the chart while last row is looping
							if (ik == (res._objDivInfoDate.length)-1) {
								//_fnDivisionByDates( divisionByDateData, divisionDates );
								_fnDivisionByDateChart( divisionByDateData );
							}
						});
					} else {
						$("#divisiondatechart .chartloader").hide();
						$("#divisiondatechart .chartloader").siblings('#info-error').text('No data found');
						return false;
					}
				}
			}).fail( function(jqXHR, textStatus, errorThrown) {
				var errMsg = $.parseJSON(jqXHR.responseText).message;
				$("#circlechart .chartloader").hide();
				$("#divisionchart .chartloader").hide();
				$("#divisiondatechart .chartloader").hide();

				$("#circlechart .chartloader").siblings('#info-error').text( (errMsg) ? errMsg : errorThrown );
				$("#divisionchart .chartloader").siblings('#info-error').text( (errMsg) ? errMsg : errorThrown );
				$("#divisiondatechart .chartloader").siblings('#info-error').text( (errMsg) ? errMsg : errorThrown );
			});
		}

		function _fnCircleChart( divisionId, divisionName ) {
			$("#circlechart .chartloader").show();

			var circount = 0;
			var _url 	 = oSettings.apiUrl + 'GetCircleData';
			var params 	 = {'IdDivision': divisionId, 'FromDate': $('#fdate').val(), 'ToDate': $('#tdate').val()};

			$.post(_url, params, function(circles) {
				if (circles != undefined && circles.length > 0) {	
					var circleData = [];
					$.each(circles, function(ik, circle) {
						circount += parseInt(circle.regCount);
						circleData.push({'y': circle.regCount, 'indexLabel': circle.circleName});
						if (ik == (circles.length)-1) {
							_fnLoadCircleChart( circleData );
							$('#circlechart').siblings().text( divisionName + ' Division Circles (' + circount + ')');
							$("#circlechart .chartloader").hide();
							return false;
						}
					});
				} else {
					//_fnLoadCircleChart( [] );
					$('#circlechart').siblings().text( divisionName + ' Division Circles (' + circount + ')');
					$("#circlechart .chartloader").hide();
					$("#circlechart .chartloader").siblings('#info-error').text('No data found');
					return false;
				}
			}).fail( function(jqXHR, textStatus, errorThrown) {
				$("#circlechart .chartloader").hide();
				$("#circlechart .chartloader").siblings('#info-error').text('Data loading failed. Please try again later');
			});
		}

		function _fnLoadCircleChart( circleData ) {
			var pieChart = new CanvasJS.Chart("circlechart", {
				animationEnabled: true,
				legend: {
					maxWidth: 350,
					itemWidth: 120
				},
				data: [{
					type: "pie",
					showInLegend: false,
					legendText: "{indexLabel}",
					dataPoints: circleData
				}]
			});

			pieChart.render();
		}

		function _fnDivisionChart( divisionData ) {
			var lineChart = new CanvasJS.Chart("divisionchart", {
				animationEnabled: true,
				toolTip: {
					cornerRadius: 5
				},
				axisX: {
					labelAngle: 90,
					interval: 1
				},
				dataPointWidth : 45,
				data: [{
					type: "column",
					cursor: "pointer",
					showInLegend: false,
					click: function(e){
    					_fnCircleChart( e.dataPoint.x, e.dataPoint.label );
    					return false;
    				},
					dataPoints: divisionData
				}]
			});
			lineChart.render();
		}

		function _fnDivisionByDateChart( divisionByDateData ) {
			var areaChart = new CanvasJS.Chart("divisiondatechart", {
			    animationEnabled: true,
			    axisX: {
			        labelFormatter: function (e) {
			            return CanvasJS.formatDate( e.value, "DD MMM YY");
			        },
			        labelAngle: -50,
			        interval: 1
			    },
			    axisY: {
			        title: "Users",
			        includeZero: false
			    },
			    toolTip: {
			        shared: true
			    },
			    data: divisionByDateData
			});
			areaChart.render();
		}

		function _fnDivisionByDates( divisionByDatesData, divisionDates ) {
			$.each(divisionDates, function(i, divisionDate){
				console.log(divisionDate);
				$.each(divisionByDatesData, function(j, divisionByDateData){
					$.each(divisionByDateData.dataPoints, function(k, dataPoint){
						console.log(dataPoint.x);
					});
				});
			});
		}

		//_fnDivisionByDateChart( divisionByDateData );
	};
	
	$.fn.Graphs = Graphs();
	
	
}(jQuery, window, document, undefined));