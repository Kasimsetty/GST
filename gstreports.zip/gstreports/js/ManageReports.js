(function ($, window, document, undefined) {

	/* Manage Reports Class */
	var ManageReports = function() {

		/* Create the settings object */
		var oSettings = $.extend( true, {}, oSettings, {
			//"apiUrl"			: "http://183.82.50.237/GST/api/",
			"apiUrl" 			: "http://192.168.30.127/GSTReports.API/api/",
			"masterData"		: false,
			"dataToBeSubmitted"	: '',
			"savedReportList"	: [],
			"reportsForm" 		: $('#newReports')
		});

		/* Init */
		_fnWorkSpace();
		_fnTableData();
		_fnLoadReport();
		_fnSaveReport();
		_fnRemoveTag();
		_fnUnselectableMetrix();

		/* Methods */
		function _fnWorkSpace() {
			_fnDefaults();
			_fnDatePickers();
			_fnAutoComplete();
			_fnLoadDivisionCircles();
			_fnSelectTab();

			//Open New Reports Tab
			$('.tab_btn:last a').trigger('click');
		}

		function _fnDefaults() {
			$('body').on('touchstart.dropdown', '.dropdown-menu', function (e) {
				e.stopPropagation();
			});

			$('.grid-table').hide();
			$('.tab-content').hide();
			$('.smloader').hide();
			$('#diventerhsn .smloader').hide();
			$('#diventersac .smloader').hide();
			$('#divcircle .smloader').hide();
			$(".loading").hide();

			// Circle
			$("#circle").select2({
				placeholder: "Select Circle",
				allowClear: true
			});
		}

		function _fnDatePickers() {
			var _datepkrs = [
				'applicationfdate',
				'applicationtdate',
				'approvalfdate',
				'approvaltdate',
				'commencementfdate',
				'commencementtdate',
				'cancellationfdate',
				'cancellationtdate'
			];

			$.each(_datepkrs, function(index, datepkr) {
				$('#' + datepkr).datepicker();

				$('#' + datepkr).siblings('div.input-group-addon').on('click', function() {
					$('#' + datepkr).datepicker({showEvent: 'none'}).data('datepicker').show();
					$('#' + datepkr).focus();
				}).css("cursor", "pointer");

				//Close datepicker when date is selected
				$('#' + datepkr).on('changeDate', function(ev) {
					$('#' + datepkr).datepicker('hide');
				});
			});

			var _date  = new Date();
			var _today = new Date((_date.getMonth() + 1) + '/' + _date.getDate() + '/' + _date.getFullYear());

			$('#applicationfdate').datepicker('setValue', _today); //set today date by default
			$('#applicationtdate').datepicker('setValue', _today.setDate(_today.getDate() + 7)); //set 1 week ahead from applicationfdate
		}

		function _fnAutoComplete() {
			$('#gstin').on(
				'keyup',function() {
					if ($(this).val().length <= 0) {
						$('#diventergst .smloader').hide();
					}
				}, 'keydown', function( event ) {
					if ( event.keyCode === $.ui.keyCode.TAB && $( this ).autocomplete( "instance" ).menu.active ) {
						event.preventDefault();
					}
				}
			).autocomplete({
				delay: 650,
				source: function( request, response ) {
					if ( request.term.length > 2 )
					{
						$('#diventergst .smloader').show();
						$.getJSON(oSettings.apiUrl + 'GetGSTIN/'+_fnExtractLast(request.term), {}, function(res) {
							response($.map(res, function (item) {
								return {
									label: item.label,
									value: item.val
								};
							}));
							$('#diventergst .smloader').hide();
						});
					} else {
						$('#diventergst .smloader').hide();
						response('');
						return false;
					}
				}
			});

			$('#sac').on(
				'keyup',function() {
					if ($(this).val().length <= 0) {
						$('#diventersac .smloader').hide();
					}
				}, 'keydown', function( event ) {
					if ( event.keyCode === $.ui.keyCode.TAB &&
						$( this ).autocomplete( "instance" ).menu.active ) {
							event.preventDefault();
					}
				}
			).autocomplete({
				source: function( request, response ) {
					if ( request.term.length > 1 )
					{
						$('#diventersac .smloader').show();
						$.getJSON(oSettings.apiUrl + 'GetSAC/'+_fnExtractLast(request.term), {}, function(res) {
							response($.map(res, function (item) {
								return {
									label: item.label,
									value: item.val
								};
							}));
							$('#diventersac .smloader').hide();
						});
					} else {
						$('#diventersac .smloader').hide();
						response('');
						return false;
					}
				},
				focus: function() {
					// prevent value inserted on focus
					return false;
				},
				select: function( event, ui ) {
					_fnAddTag( ui.item.label, ui.item.value, 'sac' );
					//this.removeAttr('placeholder');
					this.focus();
					this.value = '';
					return false;
				}
			});

			$('#hsn').on(
				'keyup',function() {
					if ($(this).val().length <= 0) {
						$('#diventerhsn .smloader').hide();
					}
				}, 'keydown', function( event ) {
					if ( event.keyCode === $.ui.keyCode.TAB && $( this ).autocomplete( "instance" ).menu.active ) {
						event.preventDefault();
					}
				}
			).autocomplete({
				source: function( request, response ) {
					if ( request.term.length > 1 )
					{
						$('#diventerhsn .smloader').show();
						$.getJSON(oSettings.apiUrl + 'GetHSN/'+_fnExtractLast(request.term), {}, function(res) {
							response($.map(res, function (item) {
								return {
									label: item.label,
									value: item.val
								};
							}));
							$('#diventerhsn .smloader').hide();
						});
					} else {
						$('#diventerhsn .smloader').hide();
						response('');
						return false;
					}
				},
				focus: function() {
					// prevent value inserted on focus
					return false;
				},
				select: function( event, ui ) {
					_fnAddTag( ui.item.label, ui.item.value, 'hsn' );
					//this.removeAttr('placeholder');
					this.focus();
					this.value = '';
					return false;
				}
			});
		}

		function _fnLoadDivisionCircles() {
			$('#division').on('change', function() {
				if($('#division').val() != null) {
					$('#divcircle .smloader').show();
					var _url = oSettings.apiUrl + 'GetCircle/' + $('#division').val();

					$.getJSON(_url, function(res) {
						/*Circle*/
						$.each(res, function (index, value) {
							$('#circle').append('<option value="' + value.key + '">' + value.value + '</option>');
						});
						$('#divcircle .smloader').hide();
					});
				} else {
					//Empty Circle List
					$("#circle").empty().trigger("change");
				}
			});
		}

		function _fnSelectTab() {
			$(".tab_btn a").click(function() {
				if( $(this).parent().siblings('.tab-content').is(':visible')) {
					$(this).removeClass('active');
					$(this).parent().siblings('.tab-content').hide();
					$(".loading").hide();
				} else {
					$('.tab-content').hide();
					$('.tab_btn a').removeClass('active');
					$(this).addClass('active');
					$(this).parent().siblings('.tab-content').fadeIn(1000);
					if (!oSettings.masterData) {
						$(".loading").show();
						_fnMasterData();
					}
				}
				return false;
			});
		}

		function _fnAddTag( taglabel, tagval, ele) {
			if ($('#'+ele).siblings('.tag').length > 0) {
				$( '<div class="tag" title="'+taglabel+'">'+tagval+'<a class="dataClose">x</a><input type="hidden" name="id" value="'+tagval+'"></div>' ).insertAfter( $('#'+ele).siblings('.tag:last') );
				_fnDecreaseElementWidth( ele );
			} else {
				$('#'+ele).parent('.tags').prepend('<div class="tag" title="'+taglabel+'">'+tagval+'<a class="dataClose">x</a><input type="hidden" name="id" value="'+tagval+'"></div>');
				_fnDecreaseElementWidth( ele );
			}
		}

		function _fnRemoveTag() {
			$('.tags').on('click', 'a.dataClose', function() {
				var ele = $(this).parents('.tag input').attr('id');
				var eleWidth = $(this).width();
				$(this).parent().remove();
				_fnIncreaseElementWidth( ele, eleWidth );
				return false;
			});
		}

		function _fnUnselectableMetrix() {
			$('.tableheaders').on('click', 'button.removeall', function(){
				$('select[name=metrix] option[value=gstin]').prop('disabled', false);
				$('select[name=metrix] option[value=gstin]').prop({'selected': true, 'disabled': true});
				$('select[name=metrix]').bootstrapDualListbox('refresh', true);
				return false;
			});
		}

		function _fnIncreaseElementWidth( ele, eleWidth ) {
			if ($('#'+ele).siblings('.tag').length > 0) {
				$( '#'+ele ).css('width', $( '#'+ele ).width() + eleWidth);
			} else {
				$( '#'+ele ).width('100%');
			}
		}

		function _fnDecreaseElementWidth( ele ) {
			if ($('#'+ele).siblings('.tag').length > 0) {
				$( '#'+ele ).css('width', $( '#'+ele ).width() - $('#'+ele).siblings('.tag:last').width());

				if ($( '#'+ele ).width() < $('#'+ele).siblings('.tag:last').width()) {
					$( '#'+ele ).css('width', $( '#'+ele ).width() + $('#'+ele).siblings('.tag:last').width());
				}
			} else {
				$( '#'+ele ).width('100%');
			}
		}

		function _fnGetTags( ele, flag ) {
			var _Tags = [];

			if (flag) {
				if ( $( '#' + ele ).siblings( '.tag' ).length > 0 ) {
					$( '#' + ele ).siblings('.tag').each(function() { 
						_Tags.push( $( 'input', $(this) ).val() );
					});
				}
			} else {
				if ( $( '#' + ele ).siblings('.tag').length > 0 ) {
					$( '#' + ele ).siblings('.tag').each(function() { 
						_Tags.push( {'label': $(this).attr('title'), 'val': $('input', $(this)).val()} );
					});
				}
			}
			return _Tags;
		}

		function _fnSplit( val ) {
			return val.split( /,\s*/ );
		}

		function _fnExtractLast( term ) {
			return _fnSplit( term ).pop();
		}

		function _fnMasterData() {
			var _url = oSettings.apiUrl + 'GetMaster';

			$.getJSON(_url, function(res) {
				if (res && res._objCon != '' && res._objDiv != '' && res._objMetrix != '') {
					var constitutions 	= res._objCon;
					var divisions		= res._objDiv;
					var metrixes 		= res._objMetrix;
					var natures 		= res._objNature;
					var reasons 		= res._objRob;
					var savedReports 	= res._objSavedReport;

					$(".loading").hide();
					oSettings.masterData = true;

					/*Reason to Obtain Registration*/
					$.each(reasons, function (index, value) {
						$('#reason').append('<option value="' + value.key + '">' + value.value + '</option>');
					});

					/*Nature of Business*/
					$.each(natures, function (index, value) {
						$('#nature').append('<option value="' + value.key + '">' + value.value + '</option>');
					});

					$('#nature').multiselect({
						enableFiltering	: true,
						nonSelectedText	: "Select Nature of Business"
					});

					/*Metrix to be Display*/
					$.each(metrixes, function (index, value) {
						$('#metrix').append('<option value="' + value.key + '">' + value.value + '</option>');
					});

					$('#metrix').bootstrapDualListbox({
						infoText				: 'Showing {0}',
						moveOnSelect			: true,
						filterTextClear			: false,
						selectedListLabel		: 'Selected Metrix:&nbsp;',
						nonSelectedFilter		: '',
						preserveSelectionOnMove	: 'moved'
					});

					$('select[name=metrix] option[value=gstin]').prop('selected', true);
					$('select[name=metrix] option[value=gstin]').prop('disabled', true);
					$('select[name=metrix]').bootstrapDualListbox('refresh', true);

					/*Division*/
					$.each(divisions, function (index, value) {
						$('#division').append('<option value="' + value.key + '">' + value.value + '</option>');
					});

					$('#division').multiselect({
						enableFiltering: true,
						nonSelectedText: "Select Division",
						numberDisplayed: 1
					});

					/*Constitution of Business*/
					$.each(constitutions, function (index, value) {
						$('#constitution').append('<option value="' + value.key + '">' + value.value + '</option>');
					});

					$('#constitution').multiselect({
						enableFiltering: true,
						nonSelectedText: "Select Constitution of Business"
					});

					/*Saved Reports*/
					$.each(savedReports, function (index, value) {
						$('#reportlist').append('<option value="' + value.key + '">' + value.value + '</option>');
						oSettings.savedReportList.push({'id': value.key, 'data': ''});
					});
			  	}
			}).fail( function(jqXHR, textStatus, errorThrown) {
				$(".loading").hide();
				$('#info-error').text('Data loading failed. Please try again later');
			});
		}

		function _fnTableData() {
			$("#reportSubmit").on('click', function() {
				$(".loading").show();

				var reportUrl 				= oSettings.apiUrl + 'GetReport';
				var selectedMetrixes 		= $("select[name=metrix] option:selected").map(function() {return $(this);}).get();
				var headersTobeDisplayed 	= [{"data" : "sno", title : "#"}];
				oSettings.dataToBeSubmitted = _fnDataToBeSubmitted();

				if (selectedMetrixes.length <= 0)
				{
					$(".loading").hide();
					alert("Please select Metrix");
					return false;
				} else {

					$.post(reportUrl, oSettings.dataToBeSubmitted, function( result ) {
						$('.grid-table').show();
						$('#reports').DataTable().destroy();
						$('#reports').empty();

						$.each(selectedMetrixes, function(index, selectedMetrix) {
							headersTobeDisplayed.push({"data" : selectedMetrix.val(), "title" : selectedMetrix.text()});
						});

						//Close New Reports Tab
						$('.tab_btn:last a').trigger('click');

						$('#reports').DataTable({
							dom			: 'Bfrtip',
							data 		: result,
							responsive	: true,
							pageLength	: 10,
							columns 	: headersTobeDisplayed,
							lengthMenu	: [[10, 20, 30, 40, 50, -1], [10, 20, 30, 40, 50, "All"]],
							initComplete: function() {
								$('.buttons-save').html('<i class="fa fa-save" />')
								$('.buttons-excel').html('<i class="fa fa-file-excel-o" />')
								$('.buttons-pdf').html('<i class="fa fa-file-pdf-o" />')
							},
							buttons		: [{
								text 		: 'Save',
								className	: 'buttons-save',
								titleAttr	: 'Save Report',
								action: function ( e, dt, node, config ) {
									var selectedDocName = "";
									if (parseInt($('#reportlist').val()) > 0) {
										selectedDocName = $("#reportlist option:selected").text();
										$('#docname').val(selectedDocName);
									}
									if ($('#saveModal .msg').length > 0) {
										$('#saveModal .msg').remove();
									}
									//$('#saveModal').fadeIn(1000);
									$('#saveModal').modal('show');
									return false;
								}
							},
							{
								extend: 'excelHtml5',
								orientation: 'landscape',
								pageSize: 'LEGAL',
								titleAttr: 'Export Excel',
								pageSize: 'LEGAL',
								title : function() {
									return (parseInt($('#reportlist').val()) > 0) ? $("#reportlist option:selected").text() : 'GST Reports';
								}
							},
							{
								extend: 'pdfHtml5',
								orientation: 'landscape',
								titleAttr: 'Export PDF',
								pageSize: 'A3',
								title : function() {
									return (parseInt($('#reportlist').val()) > 0) ? $("#reportlist option:selected").text() : 'GST Reports';
								}
							}]
						});

						$(".loading").hide();
					}).fail( function(jqXHR, textStatus, errorThrown) {
						$('#info-error').text('Error in process. Please try again later');
						$(".loading").hide();
					});
				}
				return false;
			});
		}

		function _fnDataToBeSubmitted() {
			oSettings.dataToBeSubmitted = '';
			var hsnArr = _fnGetTags( 'hsn', true );
			var sacArr = _fnGetTags( 'sac', true );

			if (hsnArr.length > 0) {
				var hsn = hsnArr.join(',');
			} else {
				var hsn = null;
			}

			if (sacArr.length > 0) {
				var sac = sacArr.join(',');
			} else {
				var sac = null;
			}

			var selectedMetrixVals = $("select[name=metrix] option:selected").map(function() {return $(this).val();}).get();

			var result = {
				"gstin"				: $("#gstin").val(),
				"arn"				: $("#arn").val(),
				"nameofbusiness"	: $("#nameofbusiness").val(),
				"tradename"			: $("#tradename").val(),
				"pan"				: $("#pan").val(),
				"email"				: $("#email").val(),
				"mobile"			: $("#mobile").val(),
				"division"			: ($("#division").val()) ? $("#division").val().join(',') : null,
				"circle"			: ($("#circle").val()) ? $("#circle").val().join(',') : null,
				"constitution"		: ($("#constitution").val()) ? $("#constitution").val().join(',') : null,
				"nature"			: ($("#nature").val()) ? $("#nature").val().join(',') : null,
				"reason"			: $("#reason").val(),
				"composition"		: $('input[name=composition]:checked').val(),
				"deemed"			: $('input[name=deemed]:checked').val(),
				"hsn"				: hsn,
				"sac"				: sac,
				"applicationfdate"	: $("#applicationfdate").val(),
				"applicationtdate"	: $("#applicationtdate").val(),
				"approvalfdate"		: $("#approvalfdate").val(),
				"approvaltdate"		: $("#approvaltdate").val(),
				"commencementfdate"	: $("#commencementfdate").val(),
				"commencementtdate"	: $("#commencementtdate").val(),
				"cancellationfdate"	: $("#cancellationfdate").val(),
				"cancellationtdate"	: $("#cancellationtdate").val(),
				"metrix"			: selectedMetrixVals.join(',')
			}

			return result;
		}

		function _fnSaveReport() {
			$( "#savereport" ).button().on( "click", function() {
				var docname = $('#docname').val();
				if ( docname != '' && docname != null ) {					                    	
					$(".srp").show();
					var _saveReportUrl 	= oSettings.apiUrl + 'SaveReport';

					var _data = oSettings.dataToBeSubmitted;

					var hsntags = _fnGetTags('hsn', false);
					var sactags = _fnGetTags('sac', false);

					_data = $.extend( {'hsntags': hsntags, 'sactags': sactags}, _data );

					var repJson = JSON.stringify(_data);
					repJson = repJson.replace(/\//g,'');

					var selectedDocId   = $('#reportlist').val();
					var selectedDocName = $("#reportlist option:selected").text();

					if (parseInt(selectedDocId) > 0 && docname == selectedDocName) {
						var dataToBeSend = {'IdReport': selectedDocId, 'ReportName': docname, "ReportJson": repJson};
						var _msg = 'updated';
					} else {
						var dataToBeSend = {'IdReport': null, 'ReportName': docname, "ReportJson": repJson};
						var _msg = 'saved';
					}

					$.post(_saveReportUrl, dataToBeSend, function( res ) {
						if (parseInt(res) > 0) {
							objIndex = oSettings.savedReportList.findIndex((obj => parseInt(obj.id) == parseInt(res)));

							if (objIndex != '' && objIndex != undefined && oSettings.savedReportList[objIndex] != '' && oSettings.savedReportList[objIndex] != undefined) {
								oSettings.savedReportList[objIndex].data = _data;
							} else {
								oSettings.savedReportList.push({'id': res, 'data': _data});
								$('#reportlist').append('<option value="' + res + '">' + docname + '</option>');
								$('#reportlist option[value=' + res + ']').prop('selected', true);
							}

							$('#saveModal .srp').after('<div class="msg"><div class="alert alert-success">' + docname + ' has been ' + _msg + ' successfully</div></div>');
							$("#saveModal .srp").hide();
							$('#saveModal .msg').fadeOut(5000, function() {
								$(this).remove();
							});
						} else {
							$('#saveModal .srp').after('<div class="msg"><div class="alert alert-danger">' + docname + 'failed to save #' + res + '</div></div>');
						}
					}).fail( function(jqXHR, textStatus, errorThrown) {
						$('#saveModal .srp').after('<div class="msg"><div class="alert alert-danger">' + docname + 'failed to save #' + res + '</div></div>');
					});
				}
			});
		}

		function _fnLoadReport() {
			$('#loadreport').on('click', function() {

				$(".loading").show();
				var reportId = parseInt($('#reportlist').val());

				if (reportId > 0) {
					_fnResetForm();

					var selectedReportList = '';

					if (oSettings.savedReportList.length > 0)
					{
						selectedReportList = oSettings.savedReportList.filter(function(v) { return parseInt(v.id) === reportId; })[0];
					}

					if (selectedReportList != '' && selectedReportList.data != '') {
						_fnPrefillReport( selectedReportList.data );
					} else {
						var _getReportUrl = oSettings.apiUrl + 'GetReportFilter/' + reportId;

						$.getJSON(_getReportUrl, function(resInputs) {
							_fnPrefillReport( JSON.parse(resInputs) );
						});
					}

					$('.tab_btn:last a').trigger('click');
					$(".loading").hide();

					return false;
				} else {
					$(".loading").hide();
					alert('Please select the report');
					$('#reportlist').focus();
					return false;
				}
			});
		}

		function _fnPrefillReport( resInputs ) {
			$.each(resInputs, function(index, val) {
				switch(index) {
					case 'gstin':
					case 'arn':
					case 'nameofbusiness':
					case 'tradeName':
					case 'pan':
					case 'email':
					case 'mobile':
					case 'reason':
						$('#'+index,  oSettings.reportsForm).val(val);
						break;

					case 'applicationfdate':
					case 'applicationtdate':
					case 'approvalfdate':
					case 'approvaltdate':
					case 'commencementfdate':
					case 'commencementtdate':
					case 'cancellationfdate':
					case 'cancellationtdate':
						if (val != null && val != '') {
							if( val.indexOf('/') != -1 ) {
								var _dateToSet  = new Date(val);
							} else {
								var _dateToSet  = new Date(val.substr(0, 2) + '/' + val.substr(2, 2) + '/' + val.substr(4));
							}
							$('#'+index,  oSettings.reportsForm).datepicker('setValue', _dateToSet);
						}
						break;

					case 'hsn':
						$.each(resInputs.hsntags, function(ht, hsntag) {
							_fnAddTag( hsntag.label, hsntag.val, 'hsn' );
						});
						break;

					case 'sac':
						$.each(resInputs.sactags, function(st, sactag) {
							_fnAddTag( sactag.label, sactag.val, 'sac' );
						});
						break;

					case 'composition':
					case 'deemed':
							$('#'+index+'[value="'+val+'"]',  oSettings.reportsForm).prop('checked', true);
						break;

					case 'constitution':
					case 'nature':
					case 'division':
							if (val != null) {
								var selectedVals = val.split(",");
								$('#'+index).val(selectedVals);
								$('#'+index).multiselect("refresh");

								if (index == 'division') {
									$('#division').trigger('change');
									setTimeout(
										function() {
											var _circles = [];
											_circles 	 = resInputs.circle.split(',');
											$("#circle").select2().select2('val', _circles);
										}, 1000
									);
								}
							}
						break;

					case 'metrix':
							var _metrixes = val.split(',');
							$.each(_metrixes, function (k, _metrix) {
								$('select[name=metrix] option[value="'+_metrix+'"]').prop('selected', true);
							});
							setTimeout(
								function() {
									$('select[name=metrix]').bootstrapDualListbox('refresh', true);
								}, 500
							);
						break;
				}
			});
		}

		function _fnResetForm() {
			var _cols = [
				'gstin',
				'arn',
				'nameofbusiness',
				'tradename',
				'pan',
				'email',
				'mobile',
				'reason',
				'hsn',
				'sac',
				'applicationfdate',
				'applicationtdate',
				'approvalfdate',
				'approvaltdate',
				'commencementfdate',
				'commencementtdate',
				'cancellationfdate',
				'cancellationtdate'
			];

			$.each(_cols, function(index, _col) {
				$('#' + _col,  oSettings.reportsForm).val('');

				if ($('#'+_col).siblings('.tag').length > 0) {
					$('#'+_col).siblings('.tag').remove();
				}
			});

			$('#composition[value="Y"], #deemed[value="Y"]',  oSettings.reportsForm).prop('checked', false);
			$('#composition[value="N"], #deemed[value="N"]',  oSettings.reportsForm).prop('checked', false);

			$("#circle").empty().trigger("change");

			$( '#constitution, #nature, #division' ).val([]);
			$( '#constitution, #nature, #division' ).multiselect("refresh");

			$('select[name=metrix] option').each(function() {
				$(this).prop('selected', false);
			});
			$('select[name=metrix]').bootstrapDualListbox('refresh', true);
		}
	};

	$.fn.ManageReports = ManageReports();

}(jQuery, window, document, undefined));